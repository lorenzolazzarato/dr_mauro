#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "drmauro.h"

void carica_campo(struct gioco *gioco, char *percorso) {

}

void riempi_campo(struct gioco *gioco, int difficolta) {

}

void step(struct gioco *gioco, enum mossa comando) {

}

enum stato vittoria(struct gioco *gioco) {
	return IN_CORSO;
}
